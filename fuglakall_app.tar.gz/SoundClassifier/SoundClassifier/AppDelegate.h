//
//  AppDelegate.h
//  fuglakall_
//
//  Created by Camila Y Cuesta Arcentales on 2/17/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

