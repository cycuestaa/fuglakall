//
//  ViewController.h
//  fuglakall_
//
//  Created by Camila Y Cuesta Arcentales on 2/17/21.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface CustomViewController : UIViewController <AVAudioRecorderDelegate, AVAudioPlayerDelegate>

@end
