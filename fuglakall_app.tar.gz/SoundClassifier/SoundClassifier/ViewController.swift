//
//  ViewController.swift
//  SoundClassifier
//
//  Created by M'haimdat omar on 24-08-2019.
//  Copyright © 2019 M'haimdat omar. All rights reserved.
//

import UIKit
import AVFoundation
import CoreML
import UIKit

class ViewController: UIViewController, AVCaptureAudioDataOutputSampleBufferDelegate, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    
    @IBOutlet var recordButton: UIButton!
    @IBOutlet var stopRedButton: UIButton!
    @IBOutlet var stopGrayButton: UIButton!
    @IBOutlet var listenButton: UIButton!
    @IBOutlet var loadBirdButton: UIButton!
    @IBOutlet var recordingLabel: UILabel!
    @IBOutlet var instrLabel: UILabel!
    @IBOutlet var activityload: UIActivityIndicatorView!
    

    let rest = RestManager()
    let server_host = "http://45.33.19.27:5000/hello"
    let server_post = "http://45.33.19.27:5000/predict"
    

    var predictionRes: String = "none"
    var tempURL: URL?
    
    var recorder: AVAudioRecorder?
    var player : AVAudioPlayer?
    
    var isReady: Bool = false
    var isRecording: Bool = false
    var isPlayBack: Bool = false
    var timer = Timer()
    var startTime = TimeInterval()
    var runtime = "0"

    
    override func viewDidLoad() {
        super.viewDidLoad()
        AVAudioSession.sharedInstance().requestRecordPermission () {
            [unowned self] allowed in
            if allowed {
                // Microphone allowed, do what you like!
                print("mic is allowed")
            } else {
                // User denied microphone. Tell them off!
            }
        }
        self.instrLabel.text = "Click button to start a new recording."
        self.recordingLabel.isHidden = true
        self.activityload.hidesWhenStopped = true
        self.activityload.stopAnimating()
        self.recordingLabel.textColor = .lightGray
        
       // Set button1's tag value.
        self.loadBirdButton.backgroundColor = .orange
        self.loadBirdButton.setTitle("Show Me Bird Caller ID!!", for: UIControl.State.normal)
        self.loadBirdButton.addTarget(self, action: #selector(processBtn), for: UIControl.Event.touchDown)
        self.loadBirdButton.addTarget(self, action: #selector(pploaded), for: UIControl.Event.valueChanged)
    }
    
    @objc func updateTime() {
        var currentTime = NSDate.timeIntervalSinceReferenceDate
        var elapsedTime: TimeInterval = currentTime - startTime
        let minutes = UInt8(elapsedTime / 60.0)
        elapsedTime -= (TimeInterval(minutes) * 60)
        
        let seconds = UInt8(elapsedTime)
        elapsedTime -= TimeInterval(seconds)

        //find out the fraction of milliseconds to be displayed
        let fraction = UInt8(elapsedTime * 100)

        //add the leading zero for minutes, seconds and millseconds and store them as string constants
        let strMinutes = String(format: "%02d", minutes)
        let strSeconds = String(format: "%02d", seconds)
        let strFraction = String(format: "%02d", fraction)

        runtime = "\(strMinutes):\(strSeconds):\(strFraction)"
        
        
        if minutes < 3 {
            self.recordingLabel.text = "Recording..." + runtime
            //self.instrLabel.text = "Recording..."
            
        } else {
            print(minutes)
            runtime = "ERR: Recording must be less than 3 minutes"
            errRecording()
      
        }
    }
    
    /* This function will process button event. */
    @objc func processBtn(_ sender: UIButton) {
        // Get button tag property value.
        self.isReady = false
        self.activityload.startAnimating()
        sender.setTitle("Looking through our call book...", for: UIControl.State.normal)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.uploadSingleFile()
        }
    }
    
    @objc func pploaded() {
        self.activityload.stopAnimating()
        performSegue(withIdentifier: "segue_res", sender: nil)
    }
    
    @IBAction func didTapListen(_ sender: UIButton) {
        let url = getAudioFileUrl()
        
        do {
            // AVAudioPlayer setting up with the saved file URL
            let sound = try AVAudioPlayer(contentsOf: url)
            self.player = sound
            
            // Here conforming to AVAudioPlayerDelegate
            sound.delegate = self
            sound.prepareToPlay()
            if isPlayBack {
                self.loadBirdButton.isEnabled = false
                self.loadBirdButton.backgroundColor = .systemGray
                self.recordButton.isEnabled = false
                sound.play()
            } else {
                self.loadBirdButton.isEnabled = true
                self.loadBirdButton.backgroundColor = .orange
                self.recordButton.isEnabled = true
                sound.stop()
            }
            isPlayBack = !isPlayBack
            
        } catch {
            print("error loading file")
            // couldn't load file :(
        }
        
    }
    func startRecording() {
        //1. create the session
        let session = AVAudioSession.sharedInstance()
        
        do {
            // 2. configure the session for recording and playback
            try session.setCategory(AVAudioSession.Category.playAndRecord, options: .defaultToSpeaker)
            try session.setActive(true)
            // 3. set up a high-quality recording session
            let settings = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 2,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            // 4. create the audio recording, and assign ourselves as the delegate
            recorder = try AVAudioRecorder(url: getAudioFileUrl(), settings: settings)
            recorder?.delegate = self
            recorder?.record()
            
            //5. Changing record icon to stop icon
            isRecording = true
            self.recordingLabel.textColor = .green
            listenButton.isEnabled = false
        }
        catch let error {
            // failed to record!
        }
    }
    
    
    @IBAction func didTapRecord(_ sender: UIButton) {
        isRecording = !isRecording
        
        print(self.recordButton.state)
        if !isRecording {
            finishRecording()
            
        } else {
            startRecording()
            runtime = ""
            self.recordButton.setImage(UIImage(named: "mic-green.png"), for: .normal)
            self.stopRedButton.isHidden = false
            self.stopGrayButton.isHidden = !self.stopGrayButton.isHidden
            self.instrLabel.text = "Click button to STOP recording"
            self.recordingLabel.text = "recording... " + runtime
            self.listenButton.isHidden = true
            self.loadBirdButton.isHidden = true
            self.recordingLabel.isHidden = false
            if !timer.isValid {
                let aSelector : Selector = #selector(updateTime)
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: aSelector, userInfo: nil, repeats: true)
            startTime = NSDate.timeIntervalSinceReferenceDate
            }
        }
    }
    
    
    // Stop recording
    func finishRecording() {
        print("finishrecording")
        recorder?.stop()
        self.isRecording = false
        self.isPlayBack = true
        self.recordButton.setImage(UIImage(named: "mic-orange.png"), for: .normal)
        self.stopRedButton.isHidden = true
        self.stopGrayButton.isHidden = false
        self.instrLabel.text = "Click button to START a new recording."
        self.listenButton.isEnabled = true
        self.listenButton.isHidden = false
        self.loadBirdButton.backgroundColor = .orange
        self.loadBirdButton.isHidden = false
        self.recordingLabel.isHidden = false
        self.recordingLabel.text = "Duration: " + runtime
        self.recordingLabel.textColor = .systemTeal

        timer.invalidate()
        //timer == nil

    }
    
    func errRecording() {
        print("errRecording")
        recorder?.stop()
        self.isRecording = false
        self.isPlayBack = false
        self.recordButton.setImage(UIImage(named: "mic-orange.png"), for: .normal)
        self.stopRedButton.isHidden = true
        self.stopGrayButton.isHidden = false
        self.instrLabel.text = "Click button to START a new recording."
        self.listenButton.isEnabled = false
        self.listenButton.isHidden = true
        self.loadBirdButton.isHidden = true
        self.loadBirdButton.backgroundColor = .systemGray
        self.recordingLabel.isHidden = false
        self.recordingLabel.text = "Duration: " + runtime
        self.recordingLabel.textColor = .systemRed

        
        timer.invalidate()
        //timer == nil

    }
    
    @IBAction func didTapStopRed(_ sender: Any) {
        if !stopRedButton.isHidden {
            finishRecording()
        }
    }
    
    
    // Path for saving/retreiving the audio file
    func getAudioFileUrl() -> URL{
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docsDirect = paths[0]
        let audioUrl = docsDirect.appendingPathComponent("recording.m4a")
        self.tempURL = audioUrl
        return audioUrl
    }

    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            finishRecording()
        }else {
            self.instrLabel.text = "Recording was interrupted. Sorry for the inconvenience... Try again"
            // Recording interrupted by other reasons like call coming, reached time limit.
        }
        
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if flag {
        }else {
            // Playing interrupted by other reasons like call coming, the sound has not finished playing.
        }
        self.recordButton.isEnabled = true
    }
    
    func randomString(length: Int) -> String {
      let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      return String((0..<length).map{ _ in letters.randomElement()! })
    }
    
    func uploadSingleFile() {
        guard let fileURL = self.tempURL else { return }
        let fname = "rec"+randomString(length: 10)+".m4a"
        let fileInfo = RestManager.FileInfo(withFileURL: fileURL, filename: fname, name: "audioFile", mimetype: "multipart/form-data", bytes: 98417)
        self.loadBirdButton.setTitleColor(UIColor.gray, for: UIControl.State.normal)
        upload(files: [fileInfo], toURL: URL(string: server_post))
    }
    
    func upload(files: [RestManager.FileInfo], toURL url: URL?) {
        print("vc upload(files:")
        if let uploadURL = url {
            print("vc url")
            print(uploadURL)
            rest.upload(files: files, toURL: uploadURL, withHttpMethod: .post) { (results, failedFilesList) in
                print("vc HTTP status code:", results.response?.httpStatusCode ?? 0)
                
                if let error = results.error {
                    print(error)
                }
                
                if let data = results.data {
                    print("founnd data in results")
                    if let toDictionary = try? JSONSerialization.jsonObject(with: data, options: .mutableContainers) {
                        print(toDictionary)
                    }
                
                    // You can print out response object
                    let responseString = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
                   //            print("responseString = \(responseString)")
                   if let responseString = responseString {
                    self.predictionRes = responseString as String
                    
                   }
                }
                
                if let failedFiles = failedFilesList {
                    for file in failedFiles {
                        print(file)
                    }
                }
                print("vc end upload")
                DispatchQueue.main.async {self.pploaded()}
                
            }
        }
    }
 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "segue_res") {
            print(self.predictionRes)
            let vc = segue.destination as! BirdResults
            vc.birdid = self.predictionRes
            
        }
    }
    
    
    
    func uploadMultipleFiles() {
        /*
        let textFileURL = Bundle.main.url(forResource: "sampleText", withExtension: "txt")
        let textFileInfo = RestManager.FileInfo(withFileURL: textFileURL, filename: "sampleText.txt", name: "uploadedFile", mimetype: "text/plain", bytes: 5)
        
        let pdfFileURL = Bundle.main.url(forResource: "samplePDF", withExtension: "pdf")
        let pdfFileInfo = RestManager.FileInfo(withFileURL: pdfFileURL, filename: "samplePDF.pdf", name: "uploadedFile", mimetype: "application/pdf", bytes: 5)
        
        let imageFileURL = Bundle.main.url(forResource: "sampleImage", withExtension: "jpg")
        let imageFileInfo = RestManager.FileInfo(withFileURL: imageFileURL, filename: "sampleImage.jpg", name: "uploadedFile", mimetype: "image/jpg", bytes: 5)
        
        upload(files: [textFileInfo, pdfFileInfo, imageFileInfo], toURL: URL(string: server_post))// + "/multiupload"))
        */
    }
    
    
    /////////////////////////////////////////////////////////////////////////////
    // MARK: - Get the inference for each sound and change the layout accordingly
    private func getInference() {
        //200 layers 100 iterations
        /*
        let model = SoundClassification()
        
        var count = 0
        _ = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { t in
            
            var wav_file: AVAudioFile!
            do {
                let fileUrl = URL(fileReferenceLiteralResourceName: "\(self.output[count])_1_converted.wav")
                wav_file = try AVAudioFile(forReading:fileUrl)
            } catch {
                fatalError("Could not open wav file.")
            }
            
            print("wav file length: \(wav_file.length)")
            assert(wav_file.fileFormat.sampleRate==16000.0, "Sample rate is not right!")
            
            let buffer = AVAudioPCMBuffer(pcmFormat: wav_file.processingFormat,
                                          frameCapacity: UInt32(wav_file.length))
            do {
                try wav_file.read(into:buffer!)
            } catch{
                fatalError("Error reading buffer.")
            }
            guard let bufferData = buffer?.floatChannelData else { return }
            
            // Chunk data and set to CoreML model
            let windowSize = 15600
            guard let audioData = try? MLMultiArray(shape:[windowSize as NSNumber],
                                                    dataType:MLMultiArrayDataType.float32)
                else {
                    fatalError("Can not create MLMultiArray")
            }
            
            // Ignore any partial window at the end.
            var results = [Dictionary<String, Double>]()
            let windowNumber = wav_file.length / Int64(windowSize)
            for windowIndex in 0..<Int(windowNumber) {
                let offset = windowIndex * windowSize
                for i in 0...windowSize {
                    audioData[i] = NSNumber.init(value: bufferData[0][offset + i])
                }
                let modelInput = SoundClassificationInput(audio: audioData)
                
                guard let modelOutput = try? model.prediction(input: modelInput) else {
                    fatalError("Error calling predict")
                }
                results.append(modelOutput.categoryProbability)
            }
            
            var prob_sums = Dictionary<String, Double>()
            for r in results {
                for (label, prob) in r {
                    prob_sums[label] = (prob_sums[label] ?? 0) + prob
                }
            }
            
            var max_sum = 0.0
            var max_sum_label = ""
            for (label, sum) in prob_sums {
                if sum > max_sum {
                    max_sum = sum
                    max_sum_label = label
                }
            }
            
            let most_probable_label = max_sum_label
            let probability = max_sum / Double(results.count)
            print("\(most_probable_label) predicted, with probability: \(probability)")
            
            let prediction: classes = classes.init(rawValue: most_probable_label)!
            
            switch prediction {
            case .dog:
                self.label.text = most_probable_label
                self.view.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
            case .helicopter:
                self.label.text = most_probable_label
                self.view.backgroundColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
            case .rooster:
                self.label.text = most_probable_label
                self.view.backgroundColor = #colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)
            case .sneezing:
                self.label.text = most_probable_label
                self.view.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            }
            print(count)
            if count >= 3 {
                t.invalidate()
            }
            count += 1
        }
        */
    }
}

