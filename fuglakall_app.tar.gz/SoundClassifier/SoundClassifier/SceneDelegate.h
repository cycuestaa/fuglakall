//
//  SceneDelegate.h
//  fuglakall_
//
//  Created by Camila Y Cuesta Arcentales on 2/17/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

