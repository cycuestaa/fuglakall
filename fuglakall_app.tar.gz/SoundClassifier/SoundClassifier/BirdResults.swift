//
//  Results.swift
//  SoundClassifier
//
//  Created by Camila Y Cuesta Arcentales on 3/18/21.
//  Copyright © 2021 M'haimdat omar. All rights reserved.
//
//

import UIKit
import AVFoundation
import CoreML
import UIKit

class BirdResults: UIViewController {
    
   /* let amecro = ""
    let brdowl = ""
    let grhowl = "https://www.allaboutbirds.org/guide/assets/photo/63741611-1280px.jpg"
    let semplo = ""
    let moudov = ""
    let none = ""
    */
    @IBOutlet var label: UILabel!
    @IBOutlet var birdImageView: UIImageView!
    @IBOutlet var subLabel: UILabel!
    
    var birdid: String!
    var imageUrlString: String!
    var infoCornellUrl = "https://ebird.org/species/"
    let output = ["American Crow", "Barred Owl" , "Great Horned Owl", "Semipalmated Plover", "Mourning Dove"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.getBirdPic()
        
    }
    
    func getBirdPic() {
        guard let most_probable_label = birdid else {print("birdid fail"); return}
        //let prediction: classes = classes.init(rawValue: most_probable_label)!
        
        switch most_probable_label {
        case "amecro":
            self.label.text = output[0]
            self.subLabel.text = "Corvus brachyrhynchos"
            self.imageUrlString = "https://www.allaboutbirds.org/guide/assets/photo/59858041-480px.jpg"
        case "brdowl":
            self.label.text = output[1]
            self.subLabel.text = "Strix varia"
            self.imageUrlString = "https://www.allaboutbirds.org/guide/assets/photo/60394891-480px.jpg"
        case "grhowl":
            self.label.text = output[2]
            self.subLabel.text = "Bubo virginianus"
            self.imageUrlString = "https://www.allaboutbirds.org/guide/assets/photo/63741611-1280px.jpg"
        case "semplo":
            self.label.text = output[3]
            self.subLabel.text = "Charadrius semipalmatus"
            self.imageUrlString = "https://www.allaboutbirds.org/guide/assets/photo/64809161-480px.jpg"
        case "moudov":
            self.label.text = output[4]
            self.subLabel.text = "Zenaida macroura"
            self.imageUrlString = "https://www.almanac.com/sites/default/files/image_nodes/bird_sounds_and_songs2-mourning_dove-us_fish_and_wildlife_wikimedia_commons.jpg"
        case "none":
            self.label.text = "No Match"
            self.subLabel.text = "Oh no! That's not in our call book.."
            self.imageUrlString = "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Flive.staticflickr.com%2F5025%2F5647490652_dafb153c53_b.jpg&f=1&nofb=1"
        default:
            self.label.text = "Try Again"
        }
        
        guard let imageUrl:URL = URL(string: imageUrlString) else {
            return
        }
        guard (try? Data(contentsOf: imageUrl)) != nil else {
          return
        }
        // Start background thread so that image loading does not make app unresponsive
          DispatchQueue.global().async { [weak self] in
            guard let self = self else { return }
            guard let imageData = try? Data(contentsOf: imageUrl) else {
                return
            }
            // When from a background thread, UI needs to be updated on main_queue
           DispatchQueue.main.async {
                let image = UIImage(data: imageData)
                self.birdImageView.image = image
            //self.birdImageView.contentMode = UIView.ContentMode.scaleAspectFit
            //self.view.addSubview(self.birdImageView)
            }
        }
        
    }
    
    @IBAction func didTapLearnMore(_ sender: UIButton) {
        print("bird: "+birdid)
        UIApplication.shared.openURL(NSURL(string: infoCornellUrl+birdid)! as URL)
    }
    
    
}

